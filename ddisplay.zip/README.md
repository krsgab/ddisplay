# A Blank PhoneGap App

## Usage

### PhoneGap CLI

    $ phonegap create my-app --template blank

### Desktop



